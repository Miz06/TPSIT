var searchData=
[
  ['add_7',['add',['../algebric_app_8c.html#aa99823a0fc8313c9c32541ce768fb801',1,'algebricApp.c']]]
];
