var searchData=
[
  ['sub_11',['sub',['../algebric_app_8c.html#aafe27965474c250fa0d582779f130d57',1,'algebricApp.c']]]
];
