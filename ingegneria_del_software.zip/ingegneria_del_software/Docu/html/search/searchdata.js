var indexSectionsWithContent =
{
  0: "adms",
  1: "a",
  2: "adms"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

