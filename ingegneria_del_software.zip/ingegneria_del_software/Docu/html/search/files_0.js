var searchData=
[
  ['algebricapp_2ec_6',['algebricApp.c',['../algebric_app_8c.html',1,'']]]
];
