var searchData=
[
  ['add_0',['add',['../algebric_app_8c.html#aa99823a0fc8313c9c32541ce768fb801',1,'algebricApp.c']]],
  ['algebricapp_2ec_1',['algebricApp.c',['../algebric_app_8c.html',1,'']]]
];
