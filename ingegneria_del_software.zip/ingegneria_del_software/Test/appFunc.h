
#ifndef APP_FUNC_H
#define APP_FUN_H

int add(int,int);
int mul(int,int);
double division(int,int);
int sub(int,int);

#endif